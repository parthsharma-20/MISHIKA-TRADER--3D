import React, { lazy, Suspense } from 'react';
import Head from 'next/head';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import MobileBottomNav from '@/components/MobileBottomNav';
import Hero3D from '@/components/Hero3D';
import Products3D from '@/components/Products3D';
import CropSolutions from '@/components/CropSolutions';
import FromSoilToHarvest from '@/components/FromSoilToHarvest';
import CropDoctor from '@/components/CropDoctor';
import FarmerSupport from '@/components/FarmerSupport';
import TodayAvailability from '@/components/TodayAvailability';
import KnowledgeCenter from '@/components/KnowledgeCenter';
import AboutSection from '@/components/AboutSection';
import Footer from '@/components/Footer';

const LoadingFallback = () => (
  <div className="w-full h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-green-100">
    <div className="text-center">
      <div className="animate-spin w-12 h-12 border-4 border-green-700 border-t-transparent rounded-full mx-auto mb-4"></div>
      <p className="text-green-700 font-semibold">Loading MISHIKA TRADER...</p>
    </div>
  </div>
);

export default function Home() {
  return (
    <>
      <Head>
        <title>MISHIKA TRADER | Premium Agricultural Solutions in Hapur - 3D Experience</title>
        <meta name="description" content="MISHIKA TRADER - Premium agricultural solutions, fertilizers, seeds, agro chemicals & crop guidance for farmers in Hapur, Uttar Pradesh. Modern 3D experience." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#2d5016" />
        <link rel="icon" href="/favicon.ico" />
        
        {/* Open Graph */}
        <meta property="og:type" content="website" />
        <meta property="og:title" content="MISHIKA TRADER | Premium Agricultural Solutions" />
        <meta property="og:description" content="Fertilizers, Seeds, Agro Chemicals & Expert Crop Guidance for Farmers in Hapur" />
        <meta property="og:url" content="https://mishikatrader.com" />
        
        {/* LocalBusiness Schema */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'LocalBusiness',
              name: 'MISHIKA TRADER',
              image: '/logo.png',
              description: 'Premium agricultural solutions and crop guidance',
              address: {
                '@type': 'PostalAddress',
                streetAddress: 'Hapur Shri Nagar Colony',
                addressLocality: 'Hapur',
                addressRegion: 'Uttar Pradesh',
                postalCode: '',
                addressCountry: 'IN',
              },
              telephone: '+91-8958083590',
              email: 'info@mishikatrader.com',
              sameAs: [
                'https://wa.me/918958083590',
              ],
            }),
          }}
        />
      </Head>

      <div className="w-full min-h-screen bg-white overflow-x-hidden">
        {/* Navigation */}
        <Navbar />

        {/* Main Content */}
        <main className="w-full">
          {/* Hero Section with 3D */}
          <Suspense fallback={<LoadingFallback />}>
            <Hero3D />
          </Suspense>

          {/* Products 3D Section */}
          <Suspense fallback={<LoadingFallback />}>
            <Products3D />
          </Suspense>

          {/* From Soil to Harvest Journey */}
          <Suspense fallback={<div className="h-96 bg-gray-100" />}>
            <FromSoilToHarvest />
          </Suspense>

          {/* Crop Solutions */}
          <Suspense fallback={<div className="h-96 bg-gray-50" />}>
            <CropSolutions />
          </Suspense>

          {/* Crop Doctor - 3D */}
          <Suspense fallback={<div className="h-96 bg-green-50" />}>
            <CropDoctor />
          </Suspense>

          {/* Today's Availability */}
          <Suspense fallback={<div className="h-96 bg-gray-100" />}>
            <TodayAvailability />
          </Suspense>

          {/* Farmer Support */}
          <Suspense fallback={<div className="h-96 bg-gray-50" />}>
            <FarmerSupport />
          </Suspense>

          {/* Knowledge Center */}
          <Suspense fallback={<div className="h-96 bg-gray-100" />}>
            <KnowledgeCenter />
          </Suspense>

          {/* About Section */}
          <Suspense fallback={<div className="h-96 bg-green-50" />}>
            <AboutSection />
          </Suspense>
        </main>

        {/* Footer */}
        <Footer />

        {/* Mobile Bottom Navigation */}
        <MobileBottomNav />
      </div>
    </>
  );
}
