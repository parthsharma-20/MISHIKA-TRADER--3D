import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, MapPin, Phone, Mail, MessageCircle, Check } from 'lucide-react';

// ===== KNOWLEDGE CENTER COMPONENT =====
export function KnowledgeCenter() {
  const articles = [
    {
      id: 1,
      category: 'Crop Guides',
      title: 'Complete Wheat Crop Guide',
      icon: '📖',
      excerpt: 'From sowing to harvest - everything you need to know',
    },
    {
      id: 2,
      category: 'Fertilizer Knowledge',
      title: 'Understanding NPK Fertilizers',
      icon: '🧪',
      excerpt: 'Why nitrogen, phosphorus, and potassium matter',
    },
    {
      id: 3,
      category: 'Pest Management',
      title: 'Basic Crop Protection Practices',
      icon: '🛡️',
      excerpt: 'Protect your crops from common pests naturally',
    },
    {
      id: 4,
      category: 'Disease Awareness',
      title: 'Micronutrients: What Farmers Should Know',
      icon: '💊',
      excerpt: 'Why trace elements are crucial for plant health',
    },
    {
      id: 5,
      category: 'Seasonal Farming',
      title: 'Monsoon Farming Tips',
      icon: '🌧️',
      excerpt: 'Best practices during rainy season farming',
    },
    {
      id: 6,
      category: 'Agriculture Updates',
      title: 'Latest Agriculture News',
      icon: '📰',
      excerpt: 'Stay updated with farming industry developments',
    },
  ];

  return (
    <section className="w-full py-20 md:py-32 bg-gradient-to-b from-white via-blue-50 to-white overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-200 rounded-full blur-3xl opacity-10" />

      <div className="relative z-10 max-w-7xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mb-16 md:mb-24"
        >
          <span className="inline-block px-4 py-2 bg-blue-100 rounded-full text-blue-700 font-semibold text-sm mb-6">
            Resources
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Farmer Knowledge Center
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Learn farming techniques and agriculture best practices from our experts
          </p>
        </motion.div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {articles.map((article, i) => (
            <motion.div
              key={article.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="group p-6 bg-white rounded-2xl border-2 border-blue-200 hover:border-blue-400 hover:shadow-lg transition-all cursor-pointer"
              whileHover={{ scale: 1.02 }}
            >
              <div className="text-4xl mb-4">{article.icon}</div>
              <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-semibold rounded-full mb-3">
                {article.category}
              </span>
              <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-700 transition-colors">
                {article.title}
              </h3>
              <p className="text-gray-600 text-sm mb-4">{article.excerpt}</p>
              <button className="text-blue-700 font-semibold text-sm hover:text-blue-900 transition-colors">
                Read More →
              </button>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="text-gray-600 text-lg mb-6">
            Want to share your farming experience or need specific information?
          </p>
          <a
            href="https://wa.me/918958083590?text=Hello%20MISHIKA%20TRADER%2C%20I%20want%20to%20know%20more%20about%20agricultural%20practices."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-4 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg"
          >
            Connect with Our Experts
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// ===== ABOUT SECTION COMPONENT =====
export function AboutSection() {
  const features = [
    'Genuine Products',
    'Farmer-Focused Service',
    'Product Availability',
    'Professional Guidance',
    'Local Support',
    'Transparent Information',
  ];

  return (
    <section className="w-full py-20 md:py-32 bg-gradient-to-b from-white via-green-50 to-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left - Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <span className="inline-block px-4 py-2 bg-green-100 rounded-full text-green-700 font-semibold text-sm mb-6">
              About MISHIKA TRADER
            </span>

            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
              Helping Farmers Make Better Agricultural Decisions
            </h2>

            <p className="text-gray-600 text-lg mb-8 leading-relaxed">
              MISHIKA TRADER is your trusted partner in agriculture. We provide premium quality fertilizers, seeds, agro-chemicals, and expert guidance to help farmers achieve better yields and sustainable growth.
            </p>

            {/* Features */}
            <div className="space-y-3 mb-8">
              {features.map((feature, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  viewport={{ once: true }}
                  className="flex items-center gap-3"
                >
                  <div className="w-6 h-6 rounded-full bg-green-700 flex items-center justify-center flex-shrink-0">
                    <Check className="text-white" size={16} />
                  </div>
                  <span className="text-gray-700 font-medium">{feature}</span>
                </motion.div>
              ))}
            </div>

            {/* CTA */}
            <div className="flex flex-col md:flex-row gap-4">
              <button className="px-8 py-4 bg-green-700 hover:bg-green-800 text-white font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg">
                Know Our Story
              </button>
              <a
                href="https://wa.me/918958083590"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 border-2 border-green-700 text-green-700 hover:bg-green-50 font-bold rounded-lg transition-all transform hover:scale-105"
              >
                Connect Now
              </a>
            </div>
          </motion.div>

          {/* Right - Image/Stats */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="bg-gradient-to-br from-green-400 to-green-600 rounded-3xl p-8 text-white">
              <div className="text-center mb-12">
                <div className="text-6xl mb-4">🌾</div>
                <h3 className="text-2xl font-bold">MISHIKA TRADER</h3>
                <p className="text-green-100 mt-2">Premium Agricultural Solutions</p>
              </div>

              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-4xl font-bold">100%</div>
                  <p className="text-green-100">Genuine Products</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold">24/7</div>
                  <p className="text-green-100">Farmer Support</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold">📍</div>
                  <p className="text-green-100">Hapur Shri Nagar Colony</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// ===== FOOTER COMPONENT =====
export function Footer() {
  return (
    <footer className="w-full bg-gray-900 text-white pt-20 pb-8 border-t-4 border-green-700">
      <div className="max-w-7xl mx-auto px-4 mb-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="mb-4">
              <div className="text-3xl font-black mb-2">MISHIKA</div>
              <div className="text-sm font-bold text-green-400">TRADER</div>
            </div>
            <p className="text-gray-400 text-sm">
              "Better Inputs. Better Guidance. Better Farming."
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h4 className="font-bold mb-4 text-green-400">Products</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-green-400 transition">Fertilizers</a></li>
              <li><a href="#" className="hover:text-green-400 transition">Seeds</a></li>
              <li><a href="#" className="hover:text-green-400 transition">Agro Chemicals</a></li>
              <li><a href="#" className="hover:text-green-400 transition">Micronutrients</a></li>
            </ul>
          </motion.div>

          {/* Resources */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="font-bold mb-4 text-green-400">Resources</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-green-400 transition">Knowledge Base</a></li>
              <li><a href="#" className="hover:text-green-400 transition">Crop Guides</a></li>
              <li><a href="#" className="hover:text-green-400 transition">FAQ</a></li>
              <li><a href="#" className="hover:text-green-400 transition">Contact</a></li>
            </ul>
          </motion.div>

          {/* Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            viewport={{ once: true }}
          >
            <h4 className="font-bold mb-4 text-green-400">Contact</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2">
                <Phone size={16} className="text-green-400" />
                <a href="tel:+918958083590" className="text-gray-400 hover:text-green-400 transition">
                  +91-8958083590
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail size={16} className="text-green-400" />
                <a href="mailto:info@mishikatrader.com" className="text-gray-400 hover:text-green-400 transition">
                  info@mishikatrader.com
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-green-400" />
                <span className="text-gray-400">Hapur Shri Nagar Colony, UP, India</span>
              </div>
              <a
                href="https://wa.me/918958083590"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 mt-3 px-4 py-2 bg-green-700 hover:bg-green-800 rounded-lg text-sm font-semibold transition-all"
              >
                <MessageCircle size={16} />
                WhatsApp Us
              </a>
            </div>
          </motion.div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-gray-400">
              © 2026 MISHIKA TRADER. All Rights Reserved.
            </p>
            <p className="text-xs text-gray-500">
              Your Digital Agriculture Partner in Hapur
            </p>
          </div>
        </div>

        {/* Legal Disclaimer */}
        <div className="mt-6 pt-6 border-t border-gray-800">
          <p className="text-xs text-gray-500 text-center">
            MISHIKA TRADER provides agricultural guidance for educational purposes. Always consult qualified agriculture professionals for medical-grade advice or pesticide recommendations.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default { KnowledgeCenter, AboutSection, Footer };
