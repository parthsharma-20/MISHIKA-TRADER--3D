import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, Send, AlertCircle } from 'lucide-react';

export default function CropDoctor() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    crop: '',
    problem: '',
    description: '',
  });
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    if (!formData.crop || !formData.problem || !formData.description) {
      alert('Please fill in all fields');
      return;
    }

    const whatsappMessage = `Hello MISHIKA TRADER, I want to send a photo of my crop problem. Crop: ${formData.crop}, Problem: ${formData.problem}, Description: ${formData.description}`;
    window.open(`https://wa.me/918958083590?text=${encodeURIComponent(whatsappMessage)}`, '_blank');
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section className="relative w-full py-20 md:py-32 bg-gradient-to-b from-white via-green-50 to-white overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-green-200 rounded-full blur-3xl opacity-10" />

      <div className="relative z-10 max-w-5xl mx-auto px-4">
        {/* Header */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div variants={itemVariants} className="mb-6">
            <span className="inline-block px-4 py-2 bg-green-100 rounded-full text-green-700 font-semibold text-sm">
              Expert Crop Analysis
            </span>
          </motion.div>

          <motion.h2
            variants={itemVariants}
            className="text-4xl md:text-5xl font-bold text-gray-900 mb-4"
          >
            Your Crop Has a Problem?
          </motion.h2>

          <motion.p
            variants={itemVariants}
            className="text-gray-600 text-lg max-w-2xl mx-auto"
          >
            Get expert diagnosis and recommendations from our agriculture professionals
          </motion.p>
        </motion.div>

        {/* Main Content */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 mb-12"
        >
          {/* Left Side - Image Upload */}
          <motion.div variants={itemVariants}>
            <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-green-50 to-blue-50 p-8 border-2 border-green-200 h-full">
              <div className="flex flex-col justify-center items-center h-full min-h-96">
                {imagePreview ? (
                  <>
                    <img 
                      src={imagePreview} 
                      alt="Crop" 
                      className="max-w-full max-h-80 rounded-lg shadow-lg mb-4 object-contain"
                    />
                    <button
                      onClick={() => document.getElementById('imageInput')?.click()}
                      className="px-6 py-2 bg-green-700 hover:bg-green-800 text-white font-semibold rounded-lg transition-all"
                    >
                      Change Photo
                    </button>
                  </>
                ) : (
                  <>
                    <div className="text-center">
                      <motion.div
                        className="w-20 h-20 bg-green-200 rounded-full flex items-center justify-center mx-auto mb-6"
                        animate={{ scale: [1, 1.05, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        <Upload className="text-green-700" size={40} />
                      </motion.div>

                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        Upload Crop Photo
                      </h3>

                      <p className="text-gray-600 text-sm mb-6">
                        Click to upload a clear photo of your crop or crop problem
                      </p>

                      <button
                        onClick={() => document.getElementById('imageInput')?.click()}
                        className="px-6 py-3 bg-green-700 hover:bg-green-800 text-white font-semibold rounded-lg transition-all inline-block mb-4"
                      >
                        Choose Photo
                      </button>

                      <p className="text-xs text-gray-500">
                        JPG, PNG (Max 5MB)
                      </p>
                    </div>
                  </>
                )}

                <input
                  id="imageInput"
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>
            </div>
          </motion.div>

          {/* Right Side - Form */}
          <motion.div variants={itemVariants}>
            <div className="rounded-2xl bg-white p-8 border-2 border-green-200 h-full">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Describe Your Issue</h3>

              <div className="space-y-5">
                {/* Crop Selection */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Select Your Crop *
                  </label>
                  <select
                    name="crop"
                    value={formData.crop}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border-2 border-green-200 rounded-lg focus:border-green-700 focus:ring-2 focus:ring-green-100 transition-all outline-none"
                  >
                    <option value="">Choose a crop...</option>
                    <option value="wheat">Wheat</option>
                    <option value="rice">Rice</option>
                    <option value="potato">Potato</option>
                    <option value="sugarcane">Sugarcane</option>
                    <option value="mustard">Mustard</option>
                    <option value="vegetables">Vegetables</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                {/* Problem Type */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Type of Problem *
                  </label>
                  <select
                    name="problem"
                    value={formData.problem}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border-2 border-green-200 rounded-lg focus:border-green-700 focus:ring-2 focus:ring-green-100 transition-all outline-none"
                  >
                    <option value="">Choose problem type...</option>
                    <option value="pest">Pest Infestation</option>
                    <option value="disease">Disease</option>
                    <option value="nutrient">Nutrient Deficiency</option>
                    <option value="discoloration">Leaf Discoloration</option>
                    <option value="wilting">Wilting/Drooping</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Detailed Description *
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Describe the problem in detail..."
                    rows={4}
                    className="w-full px-4 py-3 border-2 border-green-200 rounded-lg focus:border-green-700 focus:ring-2 focus:ring-green-100 transition-all outline-none resize-none"
                  />
                </div>

                {/* Submit Button */}
                <motion.button
                  onClick={handleSubmit}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-4 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold rounded-lg transition-all flex items-center justify-center gap-2 group"
                >
                  <Send size={20} className="group-hover:translate-x-1 transition-transform" />
                  Send for Expert Review
                </motion.button>
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* Safety Disclaimer */}
        <motion.div
          variants={itemVariants}
          className="bg-amber-50 border-2 border-amber-300 rounded-xl p-6 flex gap-4"
        >
          <AlertCircle className="text-amber-700 flex-shrink-0 mt-0.5" size={24} />
          <div>
            <h4 className="font-bold text-amber-900 mb-2">Important Disclaimer</h4>
            <p className="text-sm text-amber-800">
              Photo-based information is for preliminary guidance only. Final diagnosis and product recommendation should be verified by a qualified agriculture professional. MISHIKA TRADER recommends consulting with a certified agronomist before applying any pesticides or agrochemicals.
            </p>
          </div>
        </motion.div>

        {/* Info Section */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {[
            { num: '1', title: 'Upload Photo', desc: 'Share a clear image of the crop problem' },
            { num: '2', title: 'Describe Issue', desc: 'Provide details about the symptoms' },
            { num: '3', title: 'Get Advice', desc: 'Receive expert recommendations on WhatsApp' },
          ].map((item, i) => (
            <motion.div
              key={i}
              variants={itemVariants}
              className="text-center p-6 rounded-xl bg-white border border-green-200 hover:shadow-lg transition-shadow"
            >
              <div className="w-12 h-12 rounded-full bg-green-700 text-white flex items-center justify-center font-bold mx-auto mb-4">
                {item.num}
              </div>
              <h4 className="font-bold text-gray-900 mb-2">{item.title}</h4>
              <p className="text-sm text-gray-600">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
