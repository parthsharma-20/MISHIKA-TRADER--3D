import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

interface Crop {
  id: number;
  name: string;
  icon: string;
  concerns: string[];
  solutions: string[];
  products: string[];
}

const crops: Crop[] = [
  {
    id: 1,
    name: 'Wheat',
    icon: '🌾',
    concerns: ['Soil nutrition', 'Pest infestation', 'Fungal diseases'],
    solutions: ['Balanced NPK application', 'Timely pesticide use', 'Fungicide treatment'],
    products: ['DAP Fertilizer', 'Insecticides', 'Fungicides'],
  },
  {
    id: 2,
    name: 'Rice',
    icon: '🍚',
    concerns: ['Water management', 'Stem borer attack', 'Blast disease'],
    solutions: ['Proper irrigation', 'Insect control', 'Disease prevention'],
    products: ['NPK Fertilizer', 'Bio-pesticides', 'Micronutrients'],
  },
  {
    id: 3,
    name: 'Potato',
    icon: '🥔',
    concerns: ['Late blight', 'Scab disease', 'Nutrient deficiency'],
    solutions: ['Fungicide application', 'Seed treatment', 'Micronutrient supply'],
    products: ['Fungicides', 'Micronutrients', 'Bio-fertilizers'],
  },
  {
    id: 4,
    name: 'Sugarcane',
    icon: '🌱',
    concerns: ['Ratoon decline', 'Top borer', 'Red rot disease'],
    solutions: ['Crop rotation', 'Chemical control', 'Resistant varieties'],
    products: ['Fertilizers', 'Insecticides', 'Bio-fertilizers'],
  },
  {
    id: 5,
    name: 'Mustard',
    icon: '🌻',
    concerns: ['Alternaria blight', 'Seed rot', 'Nutrient imbalance'],
    solutions: ['Fungicide spray', 'Seed treatment', 'Balanced nutrition'],
    products: ['DAP', 'Fungicides', 'Micronutrients'],
  },
  {
    id: 6,
    name: 'Vegetables',
    icon: '🥕',
    concerns: ['Pest damage', 'Nutrient deficiency', 'Viral diseases'],
    solutions: ['Integrated pest management', 'Fertilizer schedule', 'Disease control'],
    products: ['Micronutrients', 'Bio-pesticides', 'Organic fertilizers'],
  },
];

function CropCard({ crop }: { crop: Crop }) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
      className="h-full"
    >
      <motion.div
        className="relative h-full rounded-2xl overflow-hidden cursor-pointer group"
        onClick={() => setIsExpanded(!isExpanded)}
        whileHover={{ scale: 1.02 }}
        transition={{ type: 'spring', stiffness: 300 }}
      >
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-green-400 to-green-600 opacity-0 group-hover:opacity-10 transition-opacity duration-300" />

        {/* Card */}
        <div className="relative h-full p-6 md:p-8 flex flex-col bg-white border-2 border-green-200 hover:border-green-400 transition-all">
          {/* Top Section */}
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="text-5xl mb-3">{crop.icon}</div>
              <h3 className="text-2xl font-bold text-gray-900">{crop.name}</h3>
            </div>
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.3 }}
              className="text-green-700"
            >
              <ChevronDown size={24} />
            </motion.div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-green-700 mb-3 uppercase tracking-wider">
              Common Concerns
            </h4>
            <ul className="space-y-2">
              {crop.concerns.map((concern, i) => (
                <li key={i} className="text-sm text-gray-600 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                  {concern}
                </li>
              ))}
            </ul>
          </div>

          {/* Expanded Content */}
          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-6 pt-6 border-t-2 border-green-200"
              >
                <div className="space-y-4">
                  <div>
                    <h5 className="font-semibold text-gray-900 text-sm mb-2">Solutions</h5>
                    <ul className="space-y-1">
                      {crop.solutions.map((solution, i) => (
                        <li key={i} className="text-xs text-gray-600">
                          • {solution}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h5 className="font-semibold text-gray-900 text-sm mb-2">Recommended Products</h5>
                    <div className="flex flex-wrap gap-2">
                      {crop.products.map((product, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full"
                        >
                          {product}
                        </span>
                      ))}
                    </div>
                  </div>

                  <button className="w-full mt-4 py-2 bg-green-700 hover:bg-green-800 text-white font-semibold rounded-lg transition-colors text-sm">
                    Ask Agriculture Expert
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function CropSolutions() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section className="relative w-full py-20 md:py-32 bg-gradient-to-b from-white to-green-50 overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-green-200 rounded-full blur-3xl opacity-5" />

      <div className="relative z-10 max-w-7xl mx-auto px-4">
        {/* Header */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-center mb-16 md:mb-24"
        >
          <motion.div variants={itemVariants} className="mb-6">
            <span className="inline-block px-4 py-2 bg-green-100 rounded-full text-green-700 font-semibold text-sm">
              Crop-Wise Solutions
            </span>
          </motion.div>

          <motion.h2
            variants={itemVariants}
            className="text-4xl md:text-5xl font-bold text-gray-900 mb-4"
          >
            Solutions for Every Crop
          </motion.h2>

          <motion.p
            variants={itemVariants}
            className="text-gray-600 text-lg max-w-2xl mx-auto"
          >
            Click on any crop to explore common concerns and recommended products
          </motion.p>
        </motion.div>

        {/* Crops Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {crops.map((crop) => (
            <CropCard key={crop.id} crop={crop} />
          ))}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mt-16 md:mt-24 text-center"
        >
          <motion.div variants={itemVariants}>
            <p className="text-gray-600 text-lg mb-6">
              Don't find your crop? We have solutions for all types of agriculture.
            </p>
            <a
              href="https://wa.me/918958083590?text=Hello%20MISHIKA%20TRADER%2C%20I%20need%20guidance%20regarding%20my%20crop."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-8 py-4 bg-green-700 hover:bg-green-800 text-white font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg"
            >
              Chat with Our Experts
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
