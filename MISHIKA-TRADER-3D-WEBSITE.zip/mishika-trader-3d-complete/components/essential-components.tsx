// ===== NAVBAR COMPONENT =====
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Menu, X, Phone, MessageCircle } from 'lucide-react';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Products', href: '#products' },
    { name: 'Crops', href: '#crops' },
    { name: 'Farmer Support', href: '#support' },
    { name: 'Knowledge', href: '#knowledge' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <motion.nav
      className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-md border-b border-green-200 shadow-sm"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="text-2xl font-black text-green-700">🌾</div>
          <div>
            <div className="text-xl font-black text-green-800 leading-tight">MISHIKA</div>
            <div className="text-xs font-bold text-green-600">TRADER</div>
          </div>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-gray-700 hover:text-green-700 font-medium transition-colors"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Desktop CTA */}
        <div className="hidden lg:flex items-center gap-3">
          <a href="tel:+918958083590" className="flex items-center gap-2 px-4 py-2 text-green-700 hover:bg-green-50 rounded-lg transition-colors">
            <Phone size={18} />
            <span className="font-semibold">Call</span>
          </a>
          <a
            href="https://wa.me/918958083590"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 bg-green-700 text-white hover:bg-green-800 rounded-lg transition-colors font-semibold"
          >
            <MessageCircle size={18} />
            WhatsApp
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="lg:hidden text-gray-700 hover:text-green-700"
        >
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <motion.div
          className="lg:hidden bg-white border-t border-green-200"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="px-4 py-4 space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="block text-gray-700 hover:text-green-700 font-medium transition-colors"
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <div className="flex flex-col gap-3 pt-4 border-t border-green-200">
              <a
                href="tel:+918958083590"
                className="block text-center px-4 py-2 text-green-700 border-2 border-green-700 rounded-lg font-semibold transition-colors"
              >
                📞 Call Us
              </a>
              <a
                href="https://wa.me/918958083590"
                target="_blank"
                rel="noopener noreferrer"
                className="block text-center px-4 py-2 bg-green-700 text-white rounded-lg font-semibold hover:bg-green-800 transition-colors"
              >
                💬 WhatsApp
              </a>
            </div>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
}

// ===== MOBILE BOTTOM NAV COMPONENT =====
export function MobileBottomNav() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 lg:hidden bg-white border-t border-green-200 shadow-2xl">
      <div className="grid grid-cols-5 gap-1 px-2 py-2">
        {[
          { icon: '🏠', label: 'Home', href: '#home' },
          { icon: '📦', label: 'Products', href: '#products' },
          { icon: '🌾', label: 'Crops', href: '#crops' },
          { icon: '💬', label: 'Chat', href: 'https://wa.me/918958083590' },
          { icon: '📞', label: 'Call', href: 'tel:+918958083590' },
        ].map((item, i) => (
          <a
            key={i}
            href={item.href}
            className="flex flex-col items-center justify-center py-2 text-xs font-semibold text-gray-700 hover:text-green-700 hover:bg-green-50 rounded-lg transition-all"
            target={item.href.startsWith('http') ? '_blank' : undefined}
            rel={item.href.startsWith('http') ? 'noopener noreferrer' : undefined}
          >
            <span className="text-xl mb-1">{item.icon}</span>
            {item.label}
          </a>
        ))}
      </div>
      <div className="h-4" /> {/* Spacer for phone navigation */}
    </div>
  );
}

// ===== FARMER SUPPORT COMPONENT =====
export function FarmerSupport() {
  const supportCards = [
    { icon: '👨‍🌾', title: 'Agriculture Expert', desc: 'Talk to our crop specialists' },
    { icon: '📱', title: 'WhatsApp Support', desc: 'Quick chat on WhatsApp' },
    { icon: '📦', title: 'Product Availability', desc: 'Check real-time stock' },
    { icon: '🚚', title: 'Local Service', desc: 'Fast delivery in Hapur' },
    { icon: '🌱', title: 'Crop Guidance', desc: 'Expert farming advice' },
    { icon: '📍', title: 'Hapur Store', desc: 'Visit us in person' },
  ];

  return (
    <section className="w-full py-20 md:py-32 bg-gradient-to-b from-white to-green-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mb-16 md:mb-24"
        >
          <span className="inline-block px-4 py-2 bg-green-100 rounded-full text-green-700 font-semibold text-sm mb-6">
            Farmer Support
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Always Here for Farmers
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Multiple ways to connect with our agriculture experts and support team
          </p>
        </motion.div>

        {/* Support Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {supportCards.map((card, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="p-8 bg-white rounded-2xl border-2 border-green-200 hover:border-green-400 hover:shadow-lg transition-all text-center hover:scale-105"
            >
              <div className="text-5xl mb-4">{card.icon}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{card.title}</h3>
              <p className="text-gray-600 text-sm">{card.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Quick Contact */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <p className="text-gray-700 text-lg mb-6">
            📞 <strong>+91-8958083590</strong> | 📧 info@mishikatrader.com | 📍 Hapur Shri Nagar Colony
          </p>
        </motion.div>
      </div>
    </section>
  );
}

// ===== TODAY'S AVAILABILITY COMPONENT =====
export function TodayAvailability() {
  const products = [
    { name: 'DAP', status: 'available' },
    { name: 'NPK', status: 'available' },
    { name: 'Micronutrients', status: 'available' },
    { name: 'Seeds', status: 'limited' },
    { name: 'Bio-Fertilizers', status: 'available' },
    { name: 'Fungicides', status: 'limited' },
  ];

  return (
    <section className="w-full py-20 md:py-32 bg-gradient-to-b from-green-50 to-white">
      <div className="max-w-5xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mb-16 md:mb-24"
        >
          <span className="inline-block px-4 py-2 bg-blue-100 rounded-full text-blue-700 font-semibold text-sm mb-6">
            Real-Time Stock
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Today's Availability
          </h2>
          <p className="text-gray-600 text-lg">
            Stock changes frequently. Contact MISHIKA TRADER before visiting.
          </p>
        </motion.div>

        {/* Availability Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {products.map((product, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className={`p-6 rounded-xl border-2 transition-all ${
                product.status === 'available'
                  ? 'bg-green-50 border-green-400'
                  : 'bg-yellow-50 border-yellow-400'
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900">{product.name}</h3>
                <div className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                  product.status === 'available'
                    ? 'bg-green-200 text-green-800'
                    : 'bg-yellow-200 text-yellow-800'
                }`}>
                  {product.status === 'available' ? '🟢 Available' : '🟡 Limited'}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <a
            href="https://wa.me/918958083590?text=Hello%20MISHIKA%20TRADER%2C%20I%20want%20to%20check%20the%20availability%20of%20products."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-4 bg-green-700 hover:bg-green-800 text-white font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg"
          >
            Check Full Inventory on WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
