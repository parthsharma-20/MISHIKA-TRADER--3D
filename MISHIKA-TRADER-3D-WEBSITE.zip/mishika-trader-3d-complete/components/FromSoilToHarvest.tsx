import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

interface JourneyStep {
  id: number;
  title: string;
  description: string;
  icon: string;
  color: string;
}

const journeySteps: JourneyStep[] = [
  {
    id: 1,
    title: 'Soil Preparation',
    description: 'Test your soil and prepare it with organic matter and balanced nutrients',
    icon: '🌍',
    color: '#8B7355',
  },
  {
    id: 2,
    title: 'Seed Selection',
    description: 'Choose certified seeds suitable for your climate and crop requirements',
    icon: '🌱',
    color: '#90EE90',
  },
  {
    id: 3,
    title: 'Crop Nutrition',
    description: 'Apply NPK fertilizers and micronutrients at proper growth stages',
    icon: '💪',
    color: '#FFD700',
  },
  {
    id: 4,
    title: 'Crop Protection',
    description: 'Prevent pests and diseases with timely application of agro-chemicals',
    icon: '🛡️',
    color: '#87CEEB',
  },
  {
    id: 5,
    title: 'Healthy Growth',
    description: 'Monitor crop health and maintain optimal water and nutrient levels',
    icon: '🌾',
    color: '#2d5016',
  },
  {
    id: 6,
    title: 'Successful Harvest',
    description: 'Achieve maximum yield with premium quality produce',
    icon: '✨',
    color: '#FFD700',
  },
];

function JourneyCard({ step, index }: { step: JourneyStep; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
      whileInView={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="flex flex-col items-center"
    >
      {/* Card */}
      <motion.div
        className="relative w-full md:w-80"
        whileHover={{ scale: 1.05 }}
        transition={{ type: 'spring', stiffness: 300 }}
      >
        <div className={`bg-gradient-to-br ${step.id % 2 === 0 ? 'from-white to-green-50' : 'from-green-50 to-white'} rounded-2xl p-8 shadow-lg border-2 border-green-200 hover:border-green-400 transition-colors`}>
          {/* Icon */}
          <div className="text-6xl mb-4 text-center">{step.icon}</div>

          {/* Number Badge */}
          <div className="absolute top-4 right-4 w-10 h-10 rounded-full bg-green-700 text-white flex items-center justify-center font-bold">
            {index + 1}
          </div>

          {/* Title */}
          <h3 className="text-2xl font-bold text-gray-900 mb-3 text-center">
            {step.title}
          </h3>

          {/* Description */}
          <p className="text-gray-600 text-center text-sm leading-relaxed">
            {step.description}
          </p>
        </div>
      </motion.div>

      {/* Arrow */}
      {index < journeySteps.length - 1 && (
        <motion.div
          className="md:flex hidden mt-4 mb-4 flex-col items-center"
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <ArrowRight className="text-green-700 transform rotate-90 mb-2" size={32} />
        </motion.div>
      )}
    </motion.div>
  );
}

export default function FromSoilToHarvest() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section className="relative w-full py-20 md:py-32 bg-gradient-to-b from-white via-blue-50 to-white overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-blue-200 rounded-full blur-3xl opacity-10" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-200 rounded-full blur-3xl opacity-10" />

      <div className="relative z-10 max-w-7xl mx-auto px-4">
        {/* Header */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-center mb-16 md:mb-24"
        >
          <motion.div variants={itemVariants} className="mb-6">
            <span className="inline-block px-4 py-2 bg-blue-100 rounded-full text-blue-700 font-semibold text-sm">
              Farming Journey
            </span>
          </motion.div>

          <motion.h2
            variants={itemVariants}
            className="text-4xl md:text-5xl font-bold text-gray-900 mb-4"
          >
            From Soil to Harvest
          </motion.h2>

          <motion.p
            variants={itemVariants}
            className="text-gray-600 text-lg max-w-2xl mx-auto"
          >
            A complete guide to successful farming with MISHIKA TRADER products and expertise
          </motion.p>
        </motion.div>

        {/* Journey Steps - Vertical Timeline on Mobile, Horizontal on Desktop */}
        <div className="relative">
          {/* Connector Line */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-green-400 to-transparent transform -translate-y-1/2" />

          {/* Grid Layout */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
            {journeySteps.map((step, index) => (
              <JourneyCard key={step.id} step={step} index={index} />
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mt-16 md:mt-24 text-center"
        >
          <motion.div variants={itemVariants}>
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              Ready to Transform Your Farming?
            </h3>
            <div className="flex flex-col md:flex-row gap-4 justify-center">
              <button className="px-8 py-4 bg-green-700 hover:bg-green-800 text-white font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg">
                Get Expert Guidance
              </button>
              <a
                href="https://wa.me/918958083590?text=Hello%20MISHIKA%20TRADER%2C%20I%20need%20guidance%20regarding%20my%20crop."
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 bg-green-100 hover:bg-green-200 text-green-700 font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Chat on WhatsApp
              </a>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
