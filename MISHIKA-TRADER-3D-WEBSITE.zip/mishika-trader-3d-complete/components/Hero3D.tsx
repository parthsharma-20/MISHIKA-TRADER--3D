import React, { Suspense, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment, PerspectiveCamera } from '@react-three/drei';
import * as THREE from 'three';
import { ChevronDown, Phone, MessageCircle } from 'lucide-react';

// 3D Agricultural Scene Component
function AgriculturalScene() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    setIsMobile(window.innerWidth < 768);
  }, []);

  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 5, 15]} fov={75} />
      <OrbitControls 
        autoRotate 
        autoRotateSpeed={isMobile ? 1 : 2}
        enableZoom={false}
        enablePan={false}
        maxPolarAngle={Math.PI * 0.6}
        minPolarAngle={Math.PI * 0.3}
      />

      {/* Lighting */}
      <ambientLight intensity={0.7} />
      <directionalLight 
        position={[10, 10, 5]} 
        intensity={1.2}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      <pointLight position={[-10, 5, 5]} intensity={0.5} />

      {/* Environment */}
      <Environment preset="sunset" />

      {/* Ground/Soil */}
      <mesh position={[0, -2, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial 
          color="#8B7355"
          roughness={0.8}
          metalness={0}
        />
      </mesh>

      {/* Crop Plants - Wheat */}
      {[...Array(8)].map((_, i) => (
        <CropPlant 
          key={`crop-${i}`}
          position={[
            (i % 4) * 4 - 6,
            0,
            Math.floor(i / 4) * 4 - 4
          ]}
          scale={0.8 + Math.random() * 0.3}
          rotation={[0, Math.random() * Math.PI * 2, 0]}
        />
      ))}

      {/* Fertilizer Bags */}
      {[...Array(3)].map((_, i) => (
        <FertilizerBag
          key={`fertilizer-${i}`}
          position={[-8 + i * 8, 0, -8]}
          scale={1.2}
        />
      ))}

      {/* Seed Bags */}
      {[...Array(2)].map((_, i) => (
        <SeedBag
          key={`seed-${i}`}
          position={[6 - i * 4, 0, 6]}
          scale={0.9}
        />
      ))}

      {/* Agricultural Tools */}
      <AgricultureTool position={[10, 0, -5]} rotation={[0, Math.PI / 4, 0]} />

      {/* Particle effects */}
      <ParticleEffect />
    </>
  );
}

// Crop Plant Component
function CropPlant({ position, scale, rotation }: any) {
  return (
    <group position={position} scale={scale} rotation={rotation} castShadow>
      {/* Stem */}
      <mesh position={[0, 0.4, 0]} castShadow>
        <cylinderGeometry args={[0.05, 0.08, 0.8, 6]} />
        <meshStandardMaterial color="#4a7c3a" />
      </mesh>

      {/* Leaves */}
      {[...Array(6)].map((_, i) => (
        <mesh
          key={`leaf-${i}`}
          position={[
            Math.cos((i / 6) * Math.PI * 2) * 0.15,
            0.3 + (i / 6) * 0.4,
            Math.sin((i / 6) * Math.PI * 2) * 0.15,
          ]}
          rotation={[Math.PI * 0.3, (i / 6) * Math.PI * 2, 0]}
          castShadow
        >
          <planeGeometry args={[0.15, 0.4]} />
          <meshStandardMaterial 
            color="#2d5016"
            side={THREE.DoubleSide}
            emissive="#1a3009"
            emissiveIntensity={0.2}
          />
        </mesh>
      ))}
    </group>
  );
}

// Fertilizer Bag Component
function FertilizerBag({ position, scale }: any) {
  return (
    <group position={position} scale={scale} castShadow>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[0.6, 1.2, 0.4]} />
        <meshStandardMaterial 
          color="#D2691E"
          roughness={0.7}
          metalness={0.1}
        />
      </mesh>
      {/* Label */}
      <mesh position={[0, 0.3, 0.21]}>
        <planeGeometry args={[0.55, 0.6]} />
        <meshStandardMaterial 
          color="#ffffff"
          emissive="#4a7c3a"
          emissiveIntensity={0.15}
        />
      </mesh>
    </group>
  );
}

// Seed Bag Component
function SeedBag({ position, scale }: any) {
  return (
    <group position={position} scale={scale} castShadow>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[0.4, 0.8, 0.3]} />
        <meshStandardMaterial 
          color="#90EE90"
          roughness={0.6}
          metalness={0}
        />
      </mesh>
      {/* Label */}
      <mesh position={[0, 0.15, 0.16]}>
        <planeGeometry args={[0.35, 0.5]} />
        <meshStandardMaterial 
          color="#ffffff"
          emissive="#2d5016"
          emissiveIntensity={0.2}
        />
      </mesh>
    </group>
  );
}

// Agriculture Tool Component
function AgricultureTool({ position, rotation }: any) {
  return (
    <group position={position} rotation={rotation} castShadow>
      {/* Handle */}
      <mesh position={[0, 1, 0]} castShadow>
        <cylinderGeometry args={[0.08, 0.08, 2, 8]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>
      {/* Head */}
      <mesh position={[0, 0.2, 0]} castShadow>
        <boxGeometry args={[0.6, 0.3, 0.15]} />
        <meshStandardMaterial color="#555555" roughness={0.5} metalness={0.8} />
      </mesh>
    </group>
  );
}

// Particle Effect Component
function ParticleEffect() {
  const particleCount = 20;
  const particles = React.useMemo(() => {
    return [...Array(particleCount)].map(() => ({
      x: (Math.random() - 0.5) * 30,
      y: Math.random() * 15,
      z: (Math.random() - 0.5) * 20,
      size: Math.random() * 0.05 + 0.02,
      speed: Math.random() * 0.02 + 0.01,
    }));
  }, []);

  return (
    <>
      {particles.map((particle, i) => (
        <mesh key={`particle-${i}`} position={[particle.x, particle.y, particle.z]}>
          <sphereGeometry args={[particle.size, 4, 4]} />
          <meshStandardMaterial 
            color="#90EE90"
            emissive="#4a7c3a"
            emissiveIntensity={0.5}
            wireframe={false}
          />
        </mesh>
      ))}
    </>
  );
}

// Main Hero3D Component
export default function Hero3D() {
  const [hasWebGL, setHasWebGL] = useState(true);

  useEffect(() => {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('webgl2');
      if (!gl) setHasWebGL(false);
    } catch {
      setHasWebGL(false);
    }
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2, delayChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: 'easeOut' } },
  };

  return (
    <section className="relative w-full h-screen bg-gradient-to-br from-green-50 to-blue-50 overflow-hidden flex items-center justify-center">
      {/* 3D Canvas */}
      {hasWebGL && (
        <div className="absolute inset-0 w-full h-full">
          <Canvas
            gl={{
              antialias: true,
              alpha: true,
              preserveDrawingBuffer: false,
            }}
            className="w-full h-full"
          >
            <Suspense fallback={null}>
              <AgriculturalScene />
            </Suspense>
          </Canvas>
        </div>
      )}

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-40" />

      {/* Content */}
      <motion.div
        className="relative z-10 text-center text-white max-w-3xl mx-auto px-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Brand Badge */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="inline-block px-4 py-2 bg-white/20 backdrop-blur-md rounded-full border border-white/30">
            <span className="text-sm font-semibold">Premium Agricultural Solutions</span>
          </div>
        </motion.div>

        {/* Brand Name */}
        <motion.h1
          variants={itemVariants}
          className="text-5xl md:text-7xl font-black mb-4 tracking-tight drop-shadow-lg"
        >
          MISHIKA TRADER
        </motion.h1>

        {/* Tagline */}
        <motion.p
          variants={itemVariants}
          className="text-xl md:text-2xl font-bold text-green-100 mb-6 drop-shadow-md"
        >
          "Better Inputs. Better Guidance. Better Farming."
        </motion.p>

        {/* Main Headline */}
        <motion.h2
          variants={itemVariants}
          className="text-3xl md:text-5xl font-bold mb-4 drop-shadow-lg"
        >
          Smarter Farming Starts Here.
        </motion.h2>

        {/* Subheading */}
        <motion.p
          variants={itemVariants}
          className="text-lg md:text-xl text-white/90 mb-10 drop-shadow-md"
        >
          Fertilizers, Seeds, Crop Protection & Agricultural Support — All in One Place.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          variants={itemVariants}
          className="flex flex-col md:flex-row gap-4 justify-center mb-12"
        >
          <button className="px-8 py-4 bg-green-700 hover:bg-green-800 text-white font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg">
            Explore Products
          </button>
          <button className="px-8 py-4 bg-white/20 hover:bg-white/30 text-white font-bold rounded-lg backdrop-blur-sm border border-white/30 transition-all transform hover:scale-105 shadow-lg">
            Talk to Agriculture Expert
          </button>
        </motion.div>

        {/* WhatsApp CTA */}
        <motion.a
          variants={itemVariants}
          href="https://wa.me/918958083590?text=Hello%20MISHIKA%20TRADER%2C%20I%20want%20to%20know%20more%20about%20your%20products."
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-6 py-3 bg-green-400 hover:bg-green-500 text-gray-900 font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg"
        >
          <MessageCircle size={20} />
          Chat on WhatsApp
        </motion.a>

        {/* Trust Badges */}
        <motion.div
          variants={itemVariants}
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto"
        >
          {[
            '✓ Genuine Products',
            '✓ Farmer-Focused Support',
            '✓ Easy Availability Check',
            '✓ Local Agricultural Service',
          ].map((badge, i) => (
            <div key={i} className="text-sm font-semibold bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg border border-white/20">
              {badge}
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <ChevronDown className="text-white drop-shadow-lg" size={32} />
      </motion.div>
    </section>
  );
}
