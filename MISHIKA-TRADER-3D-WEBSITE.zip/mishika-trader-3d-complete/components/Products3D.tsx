import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Leaf, Droplet, Bug, Wind, Sprout, Pill } from 'lucide-react';

interface Product3DProps {
  id: number;
  name: string;
  icon: React.ReactNode;
  description: string;
  color: string;
  gradient: string;
}

const products: Product3DProps[] = [
  {
    id: 1,
    name: 'Premium Fertilizers',
    icon: <Leaf size={40} />,
    description: 'NPK, DAP, Urea & specialized formulations',
    color: '#8B4513',
    gradient: 'from-amber-500 to-orange-600',
  },
  {
    id: 2,
    name: 'Seeds & Varieties',
    icon: <Sprout size={40} />,
    description: 'Certified hybrid & high-yield varieties',
    color: '#90EE90',
    gradient: 'from-green-500 to-emerald-600',
  },
  {
    id: 3,
    name: 'Agro Chemicals',
    icon: <Droplet size={40} />,
    description: 'Pesticides, insecticides & crop protection',
    color: '#87CEEB',
    gradient: 'from-blue-500 to-cyan-600',
  },
  {
    id: 4,
    name: 'Herbicides',
    icon: <Wind size={40} />,
    description: 'Selective & non-selective weed control',
    color: '#DEB887',
    gradient: 'from-yellow-500 to-amber-600',
  },
  {
    id: 5,
    name: 'Micronutrients',
    icon: <Pill size={40} />,
    description: 'Zinc, Iron, Boron & trace elements',
    color: '#FFB6C1',
    gradient: 'from-pink-500 to-rose-600',
  },
  {
    id: 6,
    name: 'Bio-Fertilizers',
    icon: <Sprout size={40} />,
    description: 'Natural & organic crop inputs',
    color: '#98FB98',
    gradient: 'from-lime-500 to-green-600',
  },
];

function Product3DCard({ product, index }: { product: Product3DProps; index: number }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      viewport={{ once: true }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="h-full"
    >
      <motion.div
        className={`relative h-full rounded-2xl overflow-hidden cursor-pointer group`}
        animate={{
          y: isHovered ? -12 : 0,
        }}
        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      >
        {/* Background Gradient */}
        <div className={`absolute inset-0 bg-gradient-to-br ${product.gradient} opacity-10 group-hover:opacity-20 transition-opacity duration-300`} />

        {/* Card Container */}
        <div className="relative h-full p-8 flex flex-col justify-between bg-white/50 backdrop-blur-md border border-white/80 hover:border-white/100 transition-colors">
          {/* Icon Container */}
          <motion.div
            className={`w-16 h-16 rounded-xl bg-gradient-to-br ${product.gradient} flex items-center justify-center text-white mb-6 shadow-lg`}
            animate={{
              rotateZ: isHovered ? 10 : 0,
              scale: isHovered ? 1.1 : 1,
            }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            {product.icon}
          </motion.div>

          {/* Content */}
          <div className="flex-1">
            <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-green-700 transition-colors">
              {product.name}
            </h3>
            <p className="text-gray-600 text-sm leading-relaxed mb-6">
              {product.description}
            </p>
          </div>

          {/* Action Button */}
          <motion.button
            className="w-full py-3 px-4 bg-gradient-to-r from-green-600 to-green-700 text-white font-semibold rounded-lg hover:shadow-lg transition-all"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Check Availability
          </motion.button>

          {/* Hover Effects */}
          {isHovered && (
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-white/0 via-white/10 to-white/0 pointer-events-none"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            />
          )}

          {/* Shadow Effect */}
          <motion.div
            className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-green-500 to-transparent"
            animate={{
              opacity: isHovered ? 1 : 0,
              height: isHovered ? 3 : 1,
            }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function Products3D() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section className="relative w-full py-20 md:py-32 bg-gradient-to-b from-white via-green-50 to-white overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-green-200 rounded-full blur-3xl opacity-10" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-green-100 rounded-full blur-3xl opacity-10" />

      <div className="relative z-10 max-w-7xl mx-auto px-4">
        {/* Header */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-center mb-16 md:mb-24"
        >
          <motion.div variants={itemVariants} className="mb-6">
            <span className="inline-block px-4 py-2 bg-green-100 rounded-full text-green-700 font-semibold text-sm">
              Our Premium Range
            </span>
          </motion.div>

          <motion.h2
            variants={itemVariants}
            className="text-4xl md:text-5xl font-bold text-gray-900 mb-4"
          >
            Explore Our Agricultural Solutions
          </motion.h2>

          <motion.p
            variants={itemVariants}
            className="text-gray-600 text-lg max-w-2xl mx-auto"
          >
            Everything farmers need for successful cultivation, from soil preparation to harvest
          </motion.p>
        </motion.div>

        {/* Products Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {products.map((product, index) => (
            <Product3DCard key={product.id} product={product} index={index} />
          ))}
        </motion.div>

        {/* CTA Section */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mt-16 md:mt-24 text-center"
        >
          <motion.div variants={itemVariants} className="flex flex-col md:flex-row gap-4 justify-center">
            <button className="px-8 py-4 bg-green-700 hover:bg-green-800 text-white font-bold rounded-lg transition-all transform hover:scale-105 shadow-lg">
              View Full Catalogue
            </button>
            <button className="px-8 py-4 bg-white border-2 border-green-700 text-green-700 font-bold rounded-lg hover:bg-green-50 transition-all transform hover:scale-105 shadow-lg">
              Get Expert Advice
            </button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
